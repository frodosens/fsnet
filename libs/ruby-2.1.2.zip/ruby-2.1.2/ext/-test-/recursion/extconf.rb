require 'mkmf'
create_makefile("-test-/recursion")
