require_relative '../bm_app_aobench.rb'
