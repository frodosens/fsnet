create_makefile("-test-/bug-5832/bug")
