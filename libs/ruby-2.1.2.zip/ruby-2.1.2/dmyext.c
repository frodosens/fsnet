void
Init_ext(void)
{
}

void
Init_enc(void)
{
}
